# My R programming project
# Open My_R_programming_project.Rproj first so paths below work.

# ---- 1. Load data ----
merged <- read.csv("data/clean/merged_table_clean.csv")
exam   <- read.csv("data/clean/exam_marks_clean.csv")

# ---- 2. Summary statistics ----
# summary_stats <- summary(merged)
# write.csv(as.data.frame(summary_stats), "outputs/summary_statistics.csv")

# ---- 3. Plots ----
# png("plots/histogram.png"); hist(exam$marks); dev.off()
# png("plots/boxplot.png");   boxplot(exam$marks); dev.off()
